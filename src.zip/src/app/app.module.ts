import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginformComponent } from './loginform/loginform.component';
import { FooterComponent } from './footer/footer.component';
import { SubscriptionComponent } from './subscription/subscription.component';
import {RouterModule , Routes } from '@angular/router';
import { UserService } from './user.service';
import { AuthGuardGuard } from './auth-guard.guard';
const appRoutes: Routes = [
  {
    path: '',
    component: LoginformComponent
    },
  {
  path: 'subscription',
  canActivate: [AuthGuardGuard],
  component: SubscriptionComponent
  },

];
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginformComponent,
    FooterComponent,
    SubscriptionComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [UserService, AuthGuardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
